package test.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServlet
 */
@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet {   
	
	private String html = "<!DOCTYPE html>\r\n" + 
			"<html>\r\n" + 
			"<head>\r\n" + 
			"<meta charset=\"BIG5\">\r\n" + 
			"<title>Insert title here</title>\r\n" + 
			"<style> \r\n" + 
			"img.title{ border-radius:90%%;\r\n" + 
			"		    width:10%% ;\r\n" + 
			"	    	height:10%%;\r\n" + 
			"		     box-shadow: 2px 2px 50px rgba(0,0,0,1.00);\r\n" + 
			"			}\r\n" + 
			"</style>\r\n" + 
			"</head>\r\n" + 
			"<body>\r\n" + 
			"%s%n" + 
			"</body>\r\n" + 
			"</html>";
	
	private String[] imgs = {
			"https://i2.kknews.cc/SIG=2rqo0qn/s7400040591o9n62q0n.jpg",
			"https://lh6.ggpht.com/_1L2Z7Pw7n-E/TEP2y_sHu6I/AAAAAAAAA7s/mko_c-0ChTA/s800/48f4a9a0c9e2e.jpg",
			"http://yiter1.vexp.idv.tw/~p105016/Final/jpg/alpaca3.jpg"};
	private String imgElement = 
			"<img alt='' class='title' src='%s'/>"; 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//Stream �覡
		final String imgHtml = Stream.of(imgs).
		map(s->String.format(imgElement, s)).
		collect(Collectors.joining("<br/>"));
		System.out.println(imgHtml);
		final String finalHtml = String.format(html, 
				imgHtml);

		
		//�ǲ� �覡
		final StringBuilder sb = new StringBuilder();
		for (String img : imgs) {
			final String newImg = 
					String.format(imgElement, img);
			//System.out.println(newImg);	
			sb.append(newImg);
			sb.append("<br/>");
		}
		final String finalHtml2 = String.format(html, 
				sb.toString());
		
		final PrintWriter pw =  response.getWriter();
		pw.print(finalHtml2);//��X��Ȥ��
				
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
}
