package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.Map.Entry;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestGetServelt
 */
@WebServlet("/TestGetServelt")
public class TestGetServelt extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static final String htmlTemplate = "<!DOCTYPE html>\r\n" + 
    		"<html>\r\n" + 
    		"<head>\r\n" + 
    		"<meta charset=\"UTF-8\">\r\n" + 
    		"<title>Insert title here</title>\r\n" + 
    		"<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css\" integrity=\"sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh\" crossorigin=\"anonymous\">\r\n" + 
    		"</head>\r\n" + 
    		"<body>\r\n" + 
    		"<div class=\"container\">\r\n" + 
    		"<table border=\"1\">"
    		+ "%s</table>\r\n" + 
    		"</div>\r\n" + 
    		"</body>\r\n" + 
    		"</html>";   
	private static Map<String,String> newsMap = new HashMap<>();
	//��newsMap ��l��
	static {
		newsMap.put("1", "�H�Ρm�j�ө_�L�G�ڦ訽���������n�]Lara Croft and the Temple of Osiris�^�b PC Steam ���x�i�}���ɧK�O���ʡA");
		newsMap.put("2", "Humble Store ���L���K������C���m���U����n�A�]�b�o�ӮɭԮi�}�K�O");
		newsMap.put("3", "�m������G�v���e�n���q���������ϹC���]�b Steam �i�}���K");
	}
    public TestGetServelt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    private void switchNews(String newsNumber) {
    	switch(newsNumber) {
		case "1":
			System.out.println("news1");
			break;
		case "2":
			System.out.println("news2");
			break;
		case "3":
			System.out.println("news3");
			break;	
		}
    }
    
    private String mapNews(String newsNumber) {
     	 String html = "<tr>" + 
    			"<td>���K����%s</td>" + 
    			"<td>%s</td>" + 
    			"</tr>";
    	//�p�Gkey���s�b�^��all
    	String newsInfo = newsMap.getOrDefault(newsNumber, "all");	
        
    	if (!newsInfo.equals("all")) {
    		return String.format(html, newsNumber,
    				newsMap.get(newsNumber));
    	}else {
//    		 Set<Entry<String,String>> set =  newsMap.entrySet();
//    		 StringBuilder sb = new StringBuilder();
//    		for (Entry entry :  set) {
//    			String tmp = String.format(html,
//    					entry.getKey(),entry.getValue());
//    			sb.append(tmp);
//    		}
//    		return sb.toString();
    		return newsMap.entrySet().stream().
    		map(entry->
    		String.format(html, entry.getKey(),entry.getValue())
    		).collect(Collectors.joining());
    	}
    	
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//�i��ܤ���[�W�H�U�R�O
		//������Ʈɪ��s�X
		request.setCharacterEncoding("UTF-8");
		//��ܮɪ��s�X
		response.setContentType("text/html;charset=UTF-8");
		
		String newsNumber =  request.getParameter("news");
		//switchNews(newsNumber);
		String newsHtml = mapNews(newsNumber);
		String showHtml =
				String.format(htmlTemplate, newsHtml);
	PrintWriter out = 	response.getWriter();
	out.print(showHtml);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
