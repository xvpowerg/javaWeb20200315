package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestUrlPatternServlet3
 */

//�ثe�ݨӦbweb.xml�w�q��url-pattern�|�P@WebServlet2��url-pattern�X��
@WebServlet("/TestUrlPatternServlet3")
public class TestUrlPatternServlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public TestUrlPatternServlet3() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").
		append("Servlet3");
	}



}
