package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
	
	private final String htmTmplate = "<!DOCTYPE html>\r\n" + 
			"<html>\r\n" + 
			"<head>\r\n" + 
			"<meta charset=\"UTF-8\">\r\n" + 
			"<title>Insert title here</title>\r\n" + 
			"</head>\r\n" + 
			"<body>\r\n" + 
			"%s" + 
			"</body>\r\n" + 
			"</html>";

	@Override
	protected void doPost(HttpServletRequest req, 
			HttpServletResponse resp) 
			throws ServletException, IOException {
		  //���s�����e��Servelt�ɪ��s�X    
		//req.setCharacterEncoding("UTF-8");
		//��X�]��UTF-8�ѨM��X����ýX
		   resp.setContentType("text/html;charset=UTF-8");
			PrintWriter out =  resp.getWriter();
			String defaultAcc = "qwer";
			String defaultPass = "123456";
			String account = req.getParameter("account");
			String pass = req.getParameter("pass");
			String msg = "";
			if (account.equals(defaultAcc) &&
					pass.equals(defaultPass) ) {
				 msg = String.format(htmTmplate,
						"<H1>�n�J���\</H1>");
				
			}else {
				 msg = "<H1 style='color:red'>�n���ѽЪ�^</H1>"
					+ "<input type='button'  value='��^' onClick=\"location.href='login.html';\"/> ";
				 msg = String.format(htmTmplate, msg);
			}
			
			out.println(msg);
			
	}
	
}
