package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/drawTable")
public class DrawTableServlet extends HttpServlet {
		private String htmlTemplate = "<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"BIG5\">\r\n" + 
				"<title>Insert title here</title>\r\n" + 
				"<style>"
				+ "table { border-collapse:collapse;}" + 
				"table,td {" + 
				"  border: 1px solid #0088A8; }" 
				+ "</style>"+	
				"</head>\r\n" + 
				"<body>\r\n" + 
				"%s" + 
				"</body>\r\n" + 
				"</html>";
		
		
	private void outHtml(String bodyContent,PrintWriter out) {
			String tmpHtml = String.format(htmlTemplate, bodyContent);
			out.print(tmpHtml);
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 String rowStr = req.getParameter("row");
		 String columStr = req.getParameter("col");
        PrintWriter out =    resp.getWriter();
        String errorMsg = "";
        try {
        	 int rowCount = Integer.parseInt(rowStr);
    		 int columCount = Integer.parseInt(columStr);
    		 StringBuilder sb = new StringBuilder();
    		 sb.append("<table border='1'>");
    		 //tr ���Ƭ��Ǧ�
    		 for (int i =1 ; i <= rowCount;i++) {
    			 
    			 sb.append(i%2 ==0?"<tr  style='background-color:#DDDDDD'>":"<tr>");
    			 for (int k = 1;k <= columCount;k++) {
    				 sb.append("<td>");
    				 sb.append(i+":"+k);
    				 sb.append("</td>");				 
    			 }
    			 sb.append("</tr>");
    		 }
    		 sb.append("</table>");
    		 //out.print(sb.toString());
    		 outHtml(sb.toString(),out);
        }catch(Exception ex) {
        	System.out.println("Exception:"+ex);
        	errorMsg = "Input Row and Col Field  Data Format must number";
        }
        //out.print(errorMsg);
       if (errorMsg.isEmpty() == false)
    	      outHtml(errorMsg,out);
		
		 
		
	}
	
	

}
