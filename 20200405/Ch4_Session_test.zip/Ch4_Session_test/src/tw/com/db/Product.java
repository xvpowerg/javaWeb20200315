package tw.com.db;

public class Product {
	 private int id;
     private String name;
     private int price;
     private String img;
     private String info;
     
	public Product(int id,String name, int price, String img, String info) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.img = img;
		this.info = info;
	}
	
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public int getPrice() {
		return price;
	}
	public String getImg() {
		return img;
	}
	public String getInfo() {
		return info;
	}
     
     
}
