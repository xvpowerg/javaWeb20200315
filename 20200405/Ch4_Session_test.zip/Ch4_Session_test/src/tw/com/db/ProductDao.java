package tw.com.db;

import java.util.List;

public interface ProductDao {
   //CRUD
	Product queryById(int id);
	List<Product>queryByAll();
	
}
