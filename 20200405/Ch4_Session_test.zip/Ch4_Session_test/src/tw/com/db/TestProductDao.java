package tw.com.db;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TestProductDao implements ProductDao {

	private static final Map<Integer,Product> dataMap = new HashMap<>();
	
	static {
//		private String name;
//	     private int price;
//	     private String img;
//	     private String info
		Product p1 = new Product(1,"���~1",56,"image1.jpg","100h 200w ���� �콦");
		Product p2= new Product(2,"���~2",89,"image2.jpg","100h 800w ���� �콦");
		Product p3 = new Product(3,"���~3",100,"image3.jpg","100h 300w ���� �콦");
		Product p4 = new Product(4,"���~4",92,"image4.jpg","500h 200w ���� �콦");
		Product p5 = new Product(5,"���~5",70,"image5.jpg","100h 200w ���� �콦");
		
		dataMap.put(p1.getId(), p1);
		dataMap.put(p2.getId(), p2);
		dataMap.put(p3.getId(), p3);
		dataMap.put(p4.getId(), p4);
		dataMap.put(p5.getId(), p5);
	}
	@Override
	public Product queryById(int id) {
		// TODO Auto-generated method stub
		return dataMap.get(id);
	}

	@Override
	public List<Product> queryByAll() {
		// TODO Auto-generated method stub
		List<Product> list = 
				dataMap.entrySet().stream().
					map(e->e.getValue()).collect(Collectors.toList());
		return list;
	}

}
