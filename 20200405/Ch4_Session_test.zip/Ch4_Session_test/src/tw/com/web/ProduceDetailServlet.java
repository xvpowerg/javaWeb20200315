package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.db.Product;
import tw.com.db.ProductDao;
import tw.com.db.TestProductDao;

/**
 * Servlet implementation class ProduceDetailServlet
 */
@WebServlet("/ProduceDetailServlet")
public class ProduceDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String htmlTemplate = "<!DOCTYPE html>\r\n" + 
			"<html>\r\n" + 
			"<head>\r\n" + 
			"<meta charset=\"UTF-8\">\r\n" + 
			"<title>Insert title here</title>\r\n" + 
			"<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css\" integrity=\"sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh\" crossorigin=\"anonymous\">\r\n" + 
			"</head>\r\n" + 
			"<body>\r\n" + 
			"<div style=\"height:50px\"></div>	\r\n" + 
			"	<div class=\"container\">\r\n" + 
			"		<table border=\"1\">\r\n  %s"
			+ "   </table>	\r\n" + 
			"   </div>\r\n" + 
			"</body>\r\n" + 
			"</html>";
       
	private static final String trtd = "<tr>"+ 
			"<td>%d</td>" + 
			 "<td>%s</td>" + 
			"<td><img src='images/%s'/></td>"+ 
			"<td><a href='ShoppingCar'>�[�J�ʪ���</a></td>" + 
			"</tr>";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProduceDetailServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out =   response.getWriter();
		 ProductDao pdao = new TestProductDao();
		 List<Product> list = pdao.queryByAll();
		String newTrtd = 
				list.stream().map(p->String.format(trtd,p.getId(),
				 p.getName(),p.getImg())).collect(Collectors.joining());
		String newHtml = String.format(htmlTemplate, newTrtd);
		out.print(newHtml);
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
