package tw.com.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.db.Product;
import tw.com.db.ProductDao;
import tw.com.db.TestProductDao;

/**
 * Servlet implementation class ShoppingCartServlet
 */
@WebServlet("/ShoppingCar")
public class ShoppingCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShoppingCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		String id = request.getParameter("id");
		if (id != null) {
			ProductDao pdao = new TestProductDao();
			Product p = pdao.
					queryById(Integer.parseInt(id));
			HttpSession  session =  request.getSession();
			List<Product> pList = (List) session.getAttribute("pList");
			if (pList == null) {
				pList = new ArrayList<>();
				session.setAttribute("pList", pList);
			}
			//�p�G���~���s�b��ثe�ʪ����� �~�[�J
			if (pList.contains(p) == false) {
				pList.add(p);
			}
			
			//request.getSession(true) request.getSession() �N��@�� �p�G�S���ª�Session�NCreate �p�G����Session�N�^���ª�Session
			//request.getSession(false) �N�� �p�G�S���ª�Session�N�^��null
			System.out.println(pList.size());
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
