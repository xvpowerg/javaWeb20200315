package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.db.Product;
import tw.com.db.ProductDao;
import tw.com.db.TestProductDao;

/**
 * Servlet implementation class ShoppingCartServlet
 */
@WebServlet("/ShoppingCar")
public class ShoppingCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final String htmlTemplate = "<!DOCTYPE html>\r\n" + 
			"<html>\r\n" + 
			"<head>\r\n" + 
			"<meta charset=\"UTF-8\">\r\n" + 
			"<title>Insert title here</title>\r\n" + 
			"<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css\" integrity=\"sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh\" crossorigin=\"anonymous\">\r\n" + 
			"</head>\r\n" + 
			"<body>\r\n" + 
			"<div style=\"height:50px\"></div>	\r\n" + 
			"	<div class=\"container\">\r\n" + 
			"		<table border=\"1\">\r\n  %s"
			+ "   </table>	\r\n" + 
			"   </div>\r\n" + 
			"</body>\r\n" + 
			"</html>";
       
	private static final String trtd = "<tr>"+ 
			"<td>%d</td>" + 
			 "<td>%s</td>" + 
			"<td><img src='images/%s'/></td>"+ 
			"<td><a href='ShoppingCar?id=%1$d'>�[�J�ʪ���</a></td>" + 
			"</tr>";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShoppingCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out =   response.getWriter();
		String id = request.getParameter("id");
		//request.getSession(true) request.getSession() �N��@�� �p�G�S���ª�Session�NCreate �p�G����Session�N�^���ª�Session
		//request.getSession(false) �N�� �p�G�S���ª�Session�N�^��null
		HttpSession  session =  request.getSession();
		//session ���m�s���ɶ��w�]30����
		//�i�ϥH�U��k �]�w���m�s���ɶ� �`�N��쬰��
		//session.setMaxInactiveInterval(interval);
		//�p�G���~���s�b��ثe�ʪ����� �~�[�J
		//invalidate ��k������Session �L��
		//session.invalidate();
		List<Product> pList = (List) session.getAttribute("pList");
		if (pList == null) {
			pList = new ArrayList<>();
			session.setAttribute("pList", pList);
		}
		
		//�[�J�ʪ��� ��ProduceDetailServlet �Ӫ���T
		if (id != null) {
			ProductDao pdao = new TestProductDao();
			Product p = pdao.
					queryById(Integer.parseInt(id));
			//�ˬd�o��Product �O�_�s�b��pList 
			//�p�G���s�b�N�[�J pList
				if (pList.contains(p) == false) {
				pList.add(p);
			}
		}
		
		String newTrtd = 
				pList.stream().map(p->String.format(trtd,p.getId(),
				 p.getName(),p.getImg())).collect(Collectors.joining());
		String newHtml = String.format(htmlTemplate, newTrtd);
		out.print(newHtml);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
