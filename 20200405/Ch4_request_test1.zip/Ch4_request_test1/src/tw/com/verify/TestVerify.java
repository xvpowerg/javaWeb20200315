package tw.com.verify;

import java.util.List;

public class TestVerify {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 List<String> list = VerifyNumber.verifyAge("201");
	 System.out.println(list.size());
	  list.forEach(System.out::println);
	}

}
