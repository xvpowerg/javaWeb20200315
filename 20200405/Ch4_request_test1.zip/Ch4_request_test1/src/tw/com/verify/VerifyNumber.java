package tw.com.verify;

import java.util.ArrayList;
import java.util.List;

public class VerifyNumber {

    public static  List<String> verifyAge(String age) {
    		
    	int intAge = 0;
    	List<String> errorMsgList = new ArrayList<>();
    	if (age == null || age.isEmpty()){
    		errorMsgList.add("�~�֤��i�ť�");
    		return errorMsgList;
    	}
    	
    	try {
    		intAge = Integer.parseInt(age);
        	
        	if (intAge < 13 || intAge > 200) {
        		String errorMsg = "�~�֤��i�p��13�j��200";
        		errorMsgList.add(errorMsg);
        	}
        	
    	}catch(NumberFormatException ex) {
    		errorMsgList.add(ex.getMessage());
    		
    	}
	
    	return errorMsgList;
    }
	
	
}
