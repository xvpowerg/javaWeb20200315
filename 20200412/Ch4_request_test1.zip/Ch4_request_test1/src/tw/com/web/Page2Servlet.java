package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Page2Servlet
 */
@WebServlet("/Page2")
public class Page2Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static final String templateHtml = "<!DOCTYPE html>\r\n" + 
    		"<html>\r\n" + 
    		"<head>\r\n" + 
    		"<meta charset=\"UTF-8\">\r\n" + 
    		"<title>Insert title here</title>\r\n" + 
    		"</head>\r\n" + 
    		"<body>\r\n" + 
    		"	<form action='Page3' method='get'>" + 
    		"		 <input type=\"radio\" %1$s name='mask' value='%3$d,1' >���H%3$d��</input></br>" + 
    		"		 <input type=\"radio\" %2$s name='mask' value='%4$d,2' >�ൣ%4$d��</input></br>" + 
    		"		 <button>�T�w</button>" + 
    		"	</form>\r\n" + 
    		"		\r\n" + 
    		"</body>\r\n" + 
    		"</html>";   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Page2Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		//response.getWriter().append("Page2:!!!");
		String hiddenAge = request.getParameter("hiddenAge");
		Object ageObj = request.getAttribute("age");
		if (ageObj == null) {
			ageObj = hiddenAge;
		}
		
		System.out.println("ageObj:"+ageObj);
		int age =  Integer.parseInt(ageObj.toString());
		int maskCount1 = 9,maskCount2 = 10;
		String defChecked1 = "", defChecked2 = ""; 
		if (age > 16) {
			defChecked1 = "checked";
		}else {
			defChecked2 = "checked";
			
		}
		
		String outHtml = String.format(templateHtml, 
				defChecked1,defChecked2,maskCount1,maskCount2);
		
		response.getWriter().print(outHtml);	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
