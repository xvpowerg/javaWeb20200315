package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Page3Servlet
 */
@WebServlet("/Page3")
public class Page3Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	  private static final String templateHtml = "<!DOCTYPE html>\r\n" + 
	    		"<html>\r\n" + 
	    		"<head>\r\n" + 
	    		"<meta charset=\"UTF-8\">\r\n" + 
	    		"<title>Insert title here</title>\r\n" + 
	    		"<script>"+
	    		" function toCompleteOrder(){ "+
	    		 "document.myForm.action='Page4';"+
	    		"document.myForm.submit();}"+
	    		"</script>"+
	    		
	    		"</head>\r\n" + 
	    		"<body>\r\n" + 
	    		"	<form action='Page2' method='get' name='myForm'>" + 
	    		"<p>%s</p>"+
	    		"<input type='hidden' name='hiddenAge' value='%s' />"+
	    		"<button>����</button>  <input type='button' value='�T�w'  onClick='toCompleteOrder()' />" + 
	    		"	</form>\r\n" + 
	    		"		\r\n" + 
	    		"</body>\r\n" + 
	    		"</html>"; 
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Page3Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
        response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = 	response.getWriter();
	String maskInfo =  request.getParameter("mask");
	 String[] infoArray =  maskInfo.split(",");
	 String type = infoArray[1].equals("1")?"���H":"�ൣ";
	 String age = infoArray[1].equals("1")?"17":"1";
	 
	 String info = String.format("�ƶq:%s ����:%s",infoArray[0],type );
	 String html = String.format(templateHtml, info,age);
	out.println(html);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
