package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Optional;
import java.util.stream.Stream;
/**
 * Servlet implementation class MyCookieServlet
 */
@WebServlet("/MyCookieServlet")
public class MyCookieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyCookieServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = 	response.getWriter();
        //�ϥ�Cookie�P�_�O�_���Ĥ@���n�J�ثe����
       String account =  request.getParameter("account");
       Cookie[] cookies=  request.getCookies();//���o�Ҧ���Cookie �p�G�S��Cookie�^��null
       
       if (cookies == null)cookies = new Cookie[] {};
       
    	   Stream<Cookie> cookieStream =  Stream.of(cookies);
    	   //���۹���name��accountKey �P account �� Ken��
    	      Optional<Cookie> cookieOptional=
    	    		  cookieStream.filter(c->c.getName().equals("accountKey") 
    	    		   && c.getValue().equals(account) ).findFirst();
    	      //�p�G���S��������Cookie�N��� �w��z�Ĥ@���ӧڭ̪�����!
    	    Cookie cookie =   cookieOptional.orElseGet(()->{
    	    	  Cookie myCookie = new Cookie("accountKey",account);
    	    	  out.println(account+"�w��z�Ĥ@���ӧڭ̪�����!");
    	    	  response.addCookie(myCookie);
    	    	  return null;
    	      });
      
    	    if (cookie!=null) out.println(account+"�w��z�A���ӧڭ̪�����!");
       
      
//      if (cookieOptional.isPresent()) {
//    	  cookie = cookieOptional.get();
//      }
//      
//      if (cookie == null) {
//    	  Cookie myCookie = new Cookie("accountKey",account);
//    	  response.addCookie(myCookie);
//      }
      
	}

}
