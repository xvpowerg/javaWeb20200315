package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Optional;
import java.util.stream.Stream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestCookieServlet
 */
@WebServlet("/TestCookieServlet")
public class TestCookieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestCookieServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	     response.setContentType("text/html;charset=UTF-8");
	        PrintWriter out = 	response.getWriter();

	       String account =  request.getParameter("account");
	       
	       Cookie[] cookieArray =  request.getCookies();
	  
	       if (cookieArray == null)  cookieArray = new Cookie[]{};
	       System.out.println("lenght:"+cookieArray.length);
	    Optional<Cookie> cookieOptional = Stream.of(cookieArray).filter(c->
	       					c.getName().equals(account+"_count")).findFirst();
	    Cookie cookie = 
	    		cookieOptional.orElseGet(()->new Cookie(account+"_count","0"));
	    String countStr =   cookie.getValue();
	   int count =  Integer.parseInt(countStr);
	   count++;
	   out.print("�n�J����:"+count);
	   cookie.setValue(String.valueOf(count));
	   //cookie �b�w�]���p�U �s���������N�M�����e  ����]�w��setMaxAge(-1);
	   //�i�z�LMaxAge �]�w�s���ɶ�
	   //cookie.setMaxAge(7 * 24  * 60 * 60);//�i�]�w�s���ɶ� ����
	   //cookie.setMaxAge(0);//setMaxAge(0); �ߨ����
	    //cookie.setMaxAge(-1);
	   
	   response.addCookie(cookie);//�^�s���s����
	}

}
