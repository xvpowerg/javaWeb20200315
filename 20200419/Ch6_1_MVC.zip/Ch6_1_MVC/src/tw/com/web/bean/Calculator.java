package tw.com.web.bean;
//Model
public class Calculator {
		public static int sum(int...values) {
			int sum = 0;
			for (int v :values) {
				sum += v;
			}
			return sum;
		}
		
		public static int  sum(String ... values) {
			if (values == null) return 0;
			int[] array = new int[values.length];
			for (int i =0; i<values.length ;i++) {
				array[i] = Integer.parseInt(values[i]);
			}
			return sum(array);
		}
}
