package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.web.data.ErrorMsg;


/**
 * Servlet implementation class ErrorServlet
 */
@WebServlet("/ErrorServlet")
public class ErrorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public ErrorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    
    private void errorHandle(HttpServletRequest request, 
    		HttpServletResponse response) throws IOException {
    	
        response.setContentType("text/html;charset=UTF-8");
        //���o���~���A��Code�N�X
         Integer statusCode =
        		 (Integer)request.
        		 getAttribute("javax.servlet.error.status_code");
         Exception ex = (Exception)request.
        		 getAttribute("javax.servlet.error.exception");
        PrintWriter p1 =  response.getWriter();
        
        String errorMsg = ErrorMsg.getErrorMsg(statusCode);
        //�]���n�m��application�ҥH�~�p���ϥ�
        //��ȤW�|�ϥ�Session�άOrequest�s��
        getServletContext().setAttribute("errorMsg", errorMsg);
        
        p1.println("ErrorHandle!!!...:"+statusCode);
        p1.println("Exception!!!...:"+ex);
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		errorHandle(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		errorHandle(request,response);
	}

}
