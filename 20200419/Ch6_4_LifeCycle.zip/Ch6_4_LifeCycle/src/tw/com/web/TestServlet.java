package tw.com.web;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

 
	//Servlet �b�e�����u�s�b�@��Instance(�u�| new �@�� �YServlet)
	//Servlet �w�]���p�U �u���Ĥ@���ϥΪ� �s�u�즹Servlet�� �~�|����Instance
	
	//�NServletConfig ���Y���ݩʳ]�w�� �ثe��Servlet
	//getServletContext �Ӧ۩� ServletConfig
//	public void init(ServletConfig config){
//		_ServletConfig = config;
//}
	
	//�ۤv�����e�Q��l�ƥi�Ƽginit()
	//�i�H���@Servlet���غc�l
	//�u���bServlet�Ĥ@���إ߮ɷ|�I�s!!
	public void init() {
		System.out.println("init()!!!");
		for (int i =1; i<=5;i++) {
			System.out.println("i"+i);
//			try {TimeUnit.SECONDS.sleep(1);} 
//			catch (InterruptedException e) {}
		}
	}
	
	
	//�Ӧ۩�GenericServlet
	//service ��O�����ͦs��	
	//����Http���ШDRequest �P�^��Response
	//�z�Lservice(ServletRequest req, ServletResponse res) �I�s
	//service(HttpServletRequest req, HttpServletResponse res)
		@Override
		public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
				System.out.println("service ()");
				
				super.service(req, res);
		}
	

	//HttpServlet�s�g��
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("service (Http)!!");
		
		super.service(req, resp);//�t�d�P�wmethod�������ҦpdoGet doPost....
	}


	//Servlet ����Servlet�ϥ�
	//������귽���ʧ@
	public void destroy() {
		 System.out.println("destroy!!");
	}



	/**
     * @see HttpServlet#HttpServlet()
     */
    public TestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		response.getWriter().append("Complete!!:"+Integer.toHexString(this.hashCode()) );
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
