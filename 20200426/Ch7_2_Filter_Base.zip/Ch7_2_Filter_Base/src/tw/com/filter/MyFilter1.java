package tw.com.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter("/TestServelt")
public class MyFilter1  implements Filter{

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chanin)
			throws IOException, ServletException {
		System.out.println("TestServlet doFilter!!");
		chanin.doFilter(req, res);//�|�i�JServlet
		//ServletRequest ServletResponse �|�ǤJServlet
		 Object obj =  req.getAttribute("filterMsg");
		System.out.println("TestServlet doFilter End:"+obj);
		
	}

}
