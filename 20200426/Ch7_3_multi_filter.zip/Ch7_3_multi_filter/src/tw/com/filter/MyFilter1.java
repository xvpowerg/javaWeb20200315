package tw.com.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

//�@��Filter ������h��Servelt
@WebFilter(urlPatterns = {"/TestServlet1/*","/TestServlet2"})
public class MyFilter1 implements Filter {

	@Override
	public void doFilter(ServletRequest arg0,
			ServletResponse arg1, FilterChain chain)
			throws IOException, ServletException {
		
		HttpServletRequest hsreq = (HttpServletRequest) arg0;
//���]���}��  http://localhost:8080/Ch7_3_multi_filter/TestServlet1/aaa
			System.out.println("MyFilter1!!! Start"+
			hsreq.getContextPath()+":"+//Ch7_3_multi_filter
			hsreq.getServletPath()+":"+//TestServlet1
			hsreq.getPathInfo());//aaa
			chain.doFilter(arg0, arg1);	
			
			System.out.println("MyFilter1!!! Start"+
					hsreq.getContextPath()+":"+
					hsreq.getServletPath()+":"+		
					hsreq.getPathInfo());
	}

}
