package tw.com.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class AuthFilter
 */
@WebFilter("/page/*")
public class AuthFilter implements Filter {

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		HttpServletRequest httpReq = (HttpServletRequest)   request;
		HttpServletResponse httpRes = (HttpServletResponse)response;
		//�p�G�S��Session���ܨS�n�J�L 
		//getSession(false) �p�G�S��Session�|�^��null
	  HttpSession session = httpReq.getSession(false);
	  
	  if (session != null && session.getAttribute("login") != null) {
		  chain.doFilter(request, response);
	  }else {
		  //�S�n�J�L�ΨS���\���|�^��Login.jsp
		  httpRes.sendRedirect("Login.jsp");
	  }
	  System.out.println("AuthFilter!!!");
		// pass the request along the filter chain
		//chain.doFilter(request, response);
	}

}
