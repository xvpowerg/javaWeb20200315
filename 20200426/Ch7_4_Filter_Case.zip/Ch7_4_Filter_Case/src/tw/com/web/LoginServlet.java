package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    private String account = "qwer";
    private String password = "123456";
	

    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String tmpAcc =  request.getParameter("account");
		String tmpPass = request.getParameter("pass");
	    HttpSession session =request.getSession();
		
		if (account.equals(tmpAcc) && password.equals(tmpPass)) {
			session.setAttribute("login", "Pass");
			response.sendRedirect("page/Page1.jsp");
		}
		
	}

}
