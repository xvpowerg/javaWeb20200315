package tw.com.listener;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class MySessionListener  implements HttpSessionListener{

	//ServletContextListener
	//ServletRequestAttributeListener
	//ServletRequestListener
	//HttpSessionAttributeListener
	@Override
	public void sessionCreated(HttpSessionEvent se) {
		System.out.println("sessionCreated");
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		// TODO Auto-generated method stub
		System.out.println("sessionDestroyed");
	}

	
	
}
