package tw.com.bean;

import javax.inject.Named;

@Named("Car")
public class Car implements Run {

	@Override
	public void runing() {
		System.out.println("Car runing!!!");
	}

}
