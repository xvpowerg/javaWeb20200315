package tw.com.bean;

import javax.inject.Named;

@Named("Dog")
public class Dog  implements Run{

	@Override
	public void runing() {
		System.out.println("Dog Run!!!!!...");
		
	}

}
