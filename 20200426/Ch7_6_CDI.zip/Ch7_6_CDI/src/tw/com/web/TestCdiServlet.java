package tw.com.web;

import java.io.IOException;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.bean.Book;
import tw.com.bean.Fly;
import tw.com.bean.Run;

/**
 * Servlet implementation class TestCdiServlet
 */

//CDI (Contexts and Dependency Injection) 
@WebServlet("/TestCdiServlet")
public class TestCdiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Inject
	private Book book; 
	@Inject
	private Fly myFly;
	//Fly�O�@�Ӥ��� �]���e�������u���@�����O(Bird)��@�FFly,
	// �ҥH�e���|���ڭ�new Bird ��JmyFly
	
	
	@Inject @Named("Dog")
	private Run myRun;
	@Inject @Named("Car")
	private Run myRun2;
	
	@Inject
	private List<String> myFruit;
    public TestCdiServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: "+book);
		myFly.flying();
		myRun.runing();
		myRun2.runing();
		System.out.println(myFruit);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
