package tw.com.bean;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class TestApplicationScope {
	
	private String name = "Application Empty ";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "TestApplicationScope [name=" + name + "]";
	}
	
	

}
