package tw.com.bean;

import javax.enterprise.context.RequestScoped;

@RequestScoped
public class TestRequestScope {
  private String name = "Request Empty";
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "TestRequestScope [name=" + name + "]";
	}
  
}
