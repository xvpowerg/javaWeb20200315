package tw.com.web;

import java.io.IOException;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.bean.TestRequestScope;

/**
 * Servlet implementation class TestScope
 */
@WebServlet("/TestScope")
public class TestScope extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Inject
	TestRequestScope testRequestScope;

    public TestScope() {
        super();
      
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		testRequestScope.setName("Request Howard!!");
		request.getRequestDispatcher("/TestScope2").
		forward(request, response);
		response.getWriter().append("Served at: ").
		append(request.getContextPath());
	}


}
