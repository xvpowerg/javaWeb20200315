package tw.com.cdi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;

public class DbConnection {
	@Produces
	   private Connection getConnection() {
			String url  = "jdbc:mysql://localhost:3306/userinfo?"
					+ "serverTimezone=CST&useSSL=false&allowPublicKeyRetrieval=true";
			String user = "root";
			String psaaword = "123456";
			try {
			Connection conn = DriverManager.
					getConnection(url,user,psaaword);
				return conn;
			}catch(SQLException ex) {
				System.out.println("SQLException:"+ex);
			}
			return null;
	   }
	//1 �]���ڼаO�F @Produces �b getConnection() �]���L�^��Connection
	//2   �ҥH ���ڤ�k�Ѽ� �[�W @Disposes Connection ������Connection�귽�� �|�I�s closeConnection
	private void closeConnection(@Disposes Connection con) throws SQLException {
		con.close();
	}
}
