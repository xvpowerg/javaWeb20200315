package tw.com.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

@RequestScoped
public class UserDB {
	@Inject
	private Connection con;
	public void inserUser(String name,int age) {
		try {
			PreparedStatement ps = 
			con.prepareStatement("INSERT INTO myuser(user_name,age) VALUES(?,?)");
			ps.setString(1, name);
			ps.setInt(2, age);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e);
		}
		
	}
	
	
}
