package tw.com.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

import tw.com.bean.MyUser;

@RequestScoped
public class UserDB {
	@Inject
	private Connection con;
	public void inserUser(String name,int age) {
		try {
			PreparedStatement ps = 
			con.prepareStatement("INSERT INTO myuser(user_name,age) VALUES(?,?)");
			ps.setString(1, name);
			ps.setInt(2, age);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e);
		}
		
	}
	
	public List<MyUser> queryUser(){
		List<MyUser> userList = new ArrayList<>();
		try {
			Statement stm = con.createStatement();
			ResultSet res = 
		  stm.executeQuery("SELECT * FROM myuser");
			while(res.next()) {
				int id = res.getInt(1);
				String name = res.getString(2);
				int age = res.getInt(3);
				userList.add(new MyUser(id,name,age));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		return userList;
	}
	
	
	
}
