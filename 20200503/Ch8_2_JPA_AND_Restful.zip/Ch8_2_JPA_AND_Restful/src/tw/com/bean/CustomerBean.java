package tw.com.bean;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import tw.com.entity.Customer;

/**
 * Session Bean implementation class CustomerBean
 */
//�|�Ұʥ��
//�Ѯe�����@
@Stateless
public class CustomerBean implements CustomerBeanLocal {
	@Inject
	private EntityManager em;
    /**
     * Default constructor. 
     */
    public CustomerBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public Customer createCustomer(String name, int age) {
		// TODO Auto-generated method stub
		Customer cu = new Customer();
		cu.setName(name);
		cu.setAge(age);
		em.persist(cu);
		return cu;
	}
	@Override
	public List<Customer> queryAllCustomer() {
		TypedQuery<Customer> query =
				em.createQuery("SELECT c FROM Customer c",
							Customer.class);
		  List<Customer>   list =  query.getResultList();
			if (list == null) list = new ArrayList<>();
		return list;
	}

}
