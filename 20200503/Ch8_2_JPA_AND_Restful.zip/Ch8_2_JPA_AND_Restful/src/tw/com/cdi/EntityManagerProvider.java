package tw.com.cdi;

import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class EntityManagerProvider {
	//�浹�e�����@EntityManager
	@PersistenceContext
	@Produces
	private EntityManager em;
}
