package tw.com.ws;


import java.util.List;

import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import tw.com.bean.CustomerBeanLocal;
import tw.com.entity.Customer;

@Path("customer")
@Produces(MediaType.APPLICATION_JSON)
public class CustomerRestful {
	@EJB
	CustomerBeanLocal customerBean;
	@GET
	public String queryCustomer() {
		List<Customer> list = customerBean.queryAllCustomer();
		System.out.println("list:"+list);
		return "{\"firstName\":\"Ken\"}";
	}
	@POST
	public String createCustomer(
			@QueryParam("name")
			String name,
			@QueryParam("age")
			int age) {
	Customer cu = customerBean.createCustomer(name, age);
	System.out.println("cu:"+cu);
		return "{}";
	}
}
